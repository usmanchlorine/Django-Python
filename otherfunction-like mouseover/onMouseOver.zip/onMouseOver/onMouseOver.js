function changeDivOne(){
  document.getElementById('divOne').style.backgroundColor="orange";
}

function changeDivTwo() {
  document.getElementById('divTwo').style.backgroundColor="green";
  document.body.style.backgroundColor="pink";
}

function changeText() {
  document.getElementById('para').innerHTML=":O ... you have changed all the text!"
}
